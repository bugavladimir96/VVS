var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":72,"id":5273,"methods":[{"el":48,"sc":5,"sl":41},{"el":55,"sc":13,"sl":52},{"el":71,"sc":5,"sl":50}],"name":"CglibTest","sl":34}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_1070":{"methods":[{"sl":41},{"sl":50}],"name":"test","pass":true,"statements":[{"sl":44},{"sl":45},{"sl":47},{"sl":51},{"sl":58},{"sl":59},{"sl":60},{"sl":62},{"sl":64},{"sl":66},{"sl":68},{"sl":70}]},"test_475":{"methods":[{"sl":41},{"sl":50}],"name":"test","pass":true,"statements":[{"sl":44},{"sl":45},{"sl":47},{"sl":51},{"sl":58},{"sl":59},{"sl":60},{"sl":62},{"sl":64},{"sl":66},{"sl":68},{"sl":70}]},"test_96":{"methods":[{"sl":52}],"name":"doubleAndRange","pass":true,"statements":[{"sl":54}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [475, 1070], [], [], [475, 1070], [475, 1070], [], [475, 1070], [], [], [475, 1070], [475, 1070], [96], [], [96], [], [], [], [475, 1070], [475, 1070], [475, 1070], [], [475, 1070], [], [475, 1070], [], [475, 1070], [], [475, 1070], [], [475, 1070], [], []]
