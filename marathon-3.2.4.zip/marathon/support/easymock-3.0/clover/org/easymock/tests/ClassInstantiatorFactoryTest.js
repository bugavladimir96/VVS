var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":67,"id":5289,"methods":[{"el":36,"sc":5,"sl":34},{"el":40,"sc":5,"sl":38},{"el":46,"sc":5,"sl":42},{"el":53,"sc":5,"sl":48},{"el":61,"sc":5,"sl":55},{"el":66,"sc":5,"sl":63}],"name":"ClassInstantiatorFactoryTest","sl":32}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_1036":{"methods":[{"sl":48}],"name":"getInstantiator_Overriden","pass":true,"statements":[{"sl":50},{"sl":51},{"sl":52}]},"test_105":{"methods":[{"sl":48}],"name":"getInstantiator_Overriden","pass":true,"statements":[{"sl":50},{"sl":51},{"sl":52}]},"test_1089":{"methods":[{"sl":42}],"name":"getInstantiator_Default","pass":true,"statements":[{"sl":44},{"sl":45}]},"test_644":{"methods":[{"sl":63}],"name":"getJVM","pass":true,"statements":[{"sl":65}]},"test_707":{"methods":[{"sl":63}],"name":"getJVM","pass":true,"statements":[{"sl":65}]},"test_76":{"methods":[{"sl":55}],"name":"getInstantiator_BackToDefault","pass":true,"statements":[{"sl":57},{"sl":58},{"sl":59},{"sl":60}]},"test_774":{"methods":[{"sl":55}],"name":"getInstantiator_BackToDefault","pass":true,"statements":[{"sl":57},{"sl":58},{"sl":59},{"sl":60}]},"test_994":{"methods":[{"sl":42}],"name":"getInstantiator_Default","pass":true,"statements":[{"sl":44},{"sl":45}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [1089, 994], [], [1089, 994], [1089, 994], [], [], [105, 1036], [], [105, 1036], [105, 1036], [105, 1036], [], [], [774, 76], [], [774, 76], [774, 76], [774, 76], [774, 76], [], [], [644, 707], [], [644, 707], [], []]
